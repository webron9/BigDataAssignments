## This program shows how to load a VTK Image data with extension *.vti and then
## how to access the cell data, extract one cell from the list of cells,
## access data values at each cell corner and then store the cell into a 
## vtkpolydata file format.
#################################################################################

## Import VTK
from vtk import *

## Load data
#######################################
reader = vtkXMLImageDataReader()
reader.SetFileName('Data/Isabel_2D.vti')
reader.Update()
data = reader.GetOutput()

## Query how many cells the dataset has
#######################################
numCells = data.GetNumberOfCells()
print('Total no. of cells in dataset : ',numCells)

## Dimensions of dataset
dims = data.GetDimensions()
print('Dimensions : ', dims)

## Total points in grid
totPts = data.GetNumberOfPoints()
print('Total points in grid : ',totPts)

## Range of pressure values present in data
pressureRange = data.GetScalarRange()
print('Range of pressure values present in data : ', pressureRange)

## Average of pressure values
pArray = data.GetPointData().GetArray('Pressure')
totSum = 0
for i in range(totPts):
    totSum += pArray.GetTuple1(i)
avg = totSum/totPts
print('Average of pressure values : ', avg)

## Extract cell ID
inpId = int(input('Enter cell id : '))
presCell = data.GetCell(inpId)
pt1 = presCell.GetPointId(0)
pt2 = presCell.GetPointId(1)
pt3 = presCell.GetPointId(3)
pt4 = presCell.GetPointId(2)

## Get a single cell from the list of cells
###########################################
#cell = data.GetCell(0) ## cell index = 0


## Query the 4 corner points of the cell
#########################################
#pid1 = cell.GetPointId(0)
#pid2 = cell.GetPointId(1)
#pid3 = cell.GetPointId(3)
#pid4 = cell.GetPointId(2)

## Print the 1D indices of the corner points
############################################
print('Indices of 4 corner vertices of the cell:')
print(pt1,pt2,pt3,pt4) ## in counter-clockwise order


## Get values at each vertex
## First Get the array
#dataArr = data.GetPointData().GetArray('Pressure')
v1 = pArray.GetTuple1(pt1)
v2 = pArray.GetTuple1(pt2)
v3 = pArray.GetTuple1(pt3)
v4 = pArray.GetTuple1(pt4)
#print(val1,val2,val3,val4)

## Print the locations (3D coordinates) of the points
#######################################################
print('locations (3D coordinates) of the points:')
print(data.GetPoint(pt1))
print(data.GetPoint(pt2))
print(data.GetPoint(pt3))
print(data.GetPoint(pt4))

## 3D coordindate of cell center
c_x = (data.GetPoint(pt1)[0] + data.GetPoint(pt2)[0] + data.GetPoint(pt3)[0] + data.GetPoint(pt4)[0])/4
c_y = (data.GetPoint(pt1)[1] + data.GetPoint(pt2)[1] + data.GetPoint(pt3)[1] + data.GetPoint(pt4)[1])/4
c_z = data.GetPoint(pt1)[2]
center_coordinates = (c_x,c_y,c_z)
print('3D coordindate of cell center : ', center_coordinates)

## Pressure values for all 4 coordinates
print('Pressure values of 4 co-ordinates : ')
print(data.GetPoint(pt1),':',v1)
print(data.GetPoint(pt2),':',v2)
print(data.GetPoint(pt3),':',v3)
print(data.GetPoint(pt4),':',v4)

## Average pressure values at cell center
print('Average pressure values at cell center : ')
print(center_coordinates,':',(v1+v2+v3+v4)/4)


## Question 2

x1,x2,x3,x4 = data.GetPoint(pt1)[0],data.GetPoint(pt2)[0],data.GetPoint(pt3)[0],data.GetPoint(pt4)[0]
y1,y2,y3,y4 = data.GetPoint(pt1)[1],data.GetPoint(pt2)[1],data.GetPoint(pt3)[1],data.GetPoint(pt4)[1]

# Created a new VtkPolyData object and assigned it the 4 co-ordinates of a cell.
plyData = vtkPolyData()

vpts = vtkPoints()
vpts.InsertNextPoint(x1, y1, 25)
vpts.InsertNextPoint(x2, y2, 25)
vpts.InsertNextPoint(x3, y3, 25)
vpts.InsertNextPoint(x4, y4, 25)

#Setting points array as polydata points and added it to the polydata object we created
plyData.SetPoints(vpts)

#Create the array of colors and assign them 4 different colors as : Red,Green,Blue,Yellow
colors = vtkUnsignedCharArray()
colors.SetNumberOfComponents(3)
colors.InsertNextTuple3(255, 0, 0)
colors.InsertNextTuple3(0, 255, 0)
colors.InsertNextTuple3(0, 0, 255)
colors.InsertNextTuple3(255, 255, 0)

plyData.GetPointData().SetScalars(colors) #adding to polydata object

#Add a glyph filter object to polydata object
glyphFilter = vtkVertexGlyphFilter()
glyphFilter.SetInputData(plyData)
glyphFilter.Update()

#Add a mapper to polydata object
mapper = vtkPolyDataMapper()
mapper.SetInputConnection(glyphFilter.GetOutputPort())

#Adding an actor to polydata object and increasing the size of points.
actor = vtkActor()
actor.SetScale(50)
actor.SetMapper(mapper)
actor.GetProperty().SetPointSize(10)

#Create a renderer object and output in a renderer window with white background
renderer = vtkRenderer()
renderer.AddActor(actor)
renderer.SetBackground(255,255,255)
render_window = vtkRenderWindow()
render_window.AddRenderer(renderer)

interactor = vtkRenderWindowInteractor()
interactor.SetRenderWindow(render_window)
interactor.Initialize()
interactor.Start()
