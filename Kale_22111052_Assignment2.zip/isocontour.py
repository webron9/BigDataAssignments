import vtk

# Load the VTKImageData file
reader = vtk.vtkXMLImageDataReader()
reader.SetFileName("Isabel_2D.vti")
reader.Update()

# Get the data from the reader
imageData = reader.GetOutput()

#Taking input for contourValue
contourValue = float(input("Enter the desired contour value in range(-1434.86 to 630.569) : "))

# Create a VTKPolyData object to store the contour
polyData = vtk.vtkPolyData()
points = vtk.vtkPoints()
cells = vtk.vtkCellArray()

# Loop over all cells in the grid and calculate the isocontour segments for each cell
numberOfCells = imageData.GetNumberOfCells()
for i in range(numberOfCells):
    cell = imageData.GetCell(i)
    cellPoints = cell.GetPointIds()
    point1 = imageData.GetPoint(cellPoints.GetId(0))
    point2 = imageData.GetPoint(cellPoints.GetId(1))
    point3 = imageData.GetPoint(cellPoints.GetId(3))
    point4 = imageData.GetPoint(cellPoints.GetId(2))

    value1 = imageData.GetPointData().GetScalars().GetTuple1(cellPoints.GetId(0))
    value2 = imageData.GetPointData().GetScalars().GetTuple1(cellPoints.GetId(1))
    value3 = imageData.GetPointData().GetScalars().GetTuple1(cellPoints.GetId(3))
    value4 = imageData.GetPointData().GetScalars().GetTuple1(cellPoints.GetId(2))

    # Determine the edge segments that intersect with the contour
    edge1 = (value1 <= contourValue) != (value2 <= contourValue)
    edge2 = (value2 <= contourValue) != (value3 <= contourValue)
    edge3 = (value3 <= contourValue) != (value4 <= contourValue)
    edge4 = (value4 <= contourValue) != (value1 <= contourValue)

    # Calculate the intersection points
    if edge1:
        t = abs((value1 - contourValue) / (value1 - value2))
        x = (1 - t) * point1[0] + t * point2[0]
        y = (1 - t) * point1[1] + t * point2[1]
        intersection1 = [x, y, 0]
        pointId1 = points.InsertNextPoint(intersection1)
    if edge2:
        t = abs((value2 - contourValue) / (value2 - value3))
        x = (1 - t) * point2[0] + t * point3[0]
        y = (1 - t) * point2[1] + t * point3[1]
        intersection2 = [x, y, 0]
        pointId2 = points.InsertNextPoint(intersection2)
    if edge3:
        t = abs((value3 - contourValue) / (value3 - value4))
        x = (1 - t) * point3[0] + t * point4[0]
        y = (1 - t) * point3[1] + t * point4[1]
        intersection3 = [x, y, 0]
        pointId3 = points.InsertNextPoint(intersection3)

    if edge4:
        t = abs((value4 - contourValue) / (value4 - value1))
        x = (1 - t) * point4[0] + t * point1[0]
        y = (1 - t) * point4[1] + t * point1[1]
        intersection4 = [x, y, 0]
        pointId4 = points.InsertNextPoint(intersection4)

    # Create the isocontour segments and insert them into the vtkCellArray
    if edge1 and edge2:
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, pointId1)
        line.GetPointIds().SetId(1, pointId2)
        cells.InsertNextCell(line)
        if edge3 and edge4:
            line = vtk.vtkLine()
            line.GetPointIds().SetId(0, pointId3)
            line.GetPointIds().SetId(1, pointId4)
            cells.InsertNextCell(line)
    elif edge2 and edge3:
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, pointId2)
        line.GetPointIds().SetId(1, pointId3)
        cells.InsertNextCell(line)
    elif edge3 and edge4:
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, pointId3)
        line.GetPointIds().SetId(1, pointId4)
        cells.InsertNextCell(line)
    elif edge4 and edge1:
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, pointId4)
        line.GetPointIds().SetId(1, pointId1)
        cells.InsertNextCell(line)
    elif edge1 and edge3:
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, pointId1)
        line.GetPointIds().SetId(1, pointId3)
        cells.InsertNextCell(line)
    elif edge2 and edge4:
        line = vtk.vtkLine()
        line.GetPointIds().SetId(0, pointId2)
        line.GetPointIds().SetId(1, pointId4)
        cells.InsertNextCell(line)

# Set the points and cells in the VTKPolyData object
polyData.SetPoints(points)
polyData.SetLines(cells)

colors = vtk.vtkUnsignedCharArray()
colors.SetNumberOfComponents(3)
colors.SetName("Colors")
colors.SetNumberOfTuples(numberOfCells)

# set the color of all the cells to red
for i in range(numberOfCells):
    colors.SetTuple3(i, 255, 0, 0)

polyData.GetCellData().SetScalars(colors)

# Write the VTKPolyData object to a file
writer = vtk.vtkXMLPolyDataWriter()
writer.SetFileName("output.vtp")
writer.SetInputData(polyData)
writer.Write()
