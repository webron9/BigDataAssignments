import vtk

# create a vtkImageData reader object
reader = vtk.vtkXMLImageDataReader()

# set the filename of the 3D data to load and update the reader
reader.SetFileName("Isabel_3D.vti")
reader.Update()

# get the output of the reader, which is a vtkImageData object
imageData = reader.GetOutput()

# create an instance of vtkColorTransferFunction and set it up with the values provided below
colorTransferFunction = vtk.vtkColorTransferFunction()
colorTransferFunction.AddRGBPoint(-4931.54, 0, 1, 1)
colorTransferFunction.AddRGBPoint(-2508.95, 0, 0, 1)
colorTransferFunction.AddRGBPoint(-1873.9, 0, 0, 0.5)
colorTransferFunction.AddRGBPoint(-1027.16, 1, 0, 0)
colorTransferFunction.AddRGBPoint(-298.031, 1, 0.4, 0)
colorTransferFunction.AddRGBPoint(2594.97, 1, 1, 0)


# create an instance of vtkPiecewiseFunction and set it up with the values provided below
opacityTransferFunction = vtk.vtkPiecewiseFunction()
opacityTransferFunction.AddPoint(-4931.54, 1.0)
opacityTransferFunction.AddPoint(101.815, 0.002)
opacityTransferFunction.AddPoint(2594.97, 0.0)

# create a vtkSmartVolumeMapper object and set its input data and volume property
volumeMapper = vtk.vtkSmartVolumeMapper()
volumeMapper.SetInputData(imageData)

# create a vtkVolume object and set its mapper to the vtkSmartVolumeMapper object
volume = vtk.vtkVolume()
volume.SetMapper(volumeMapper)
volume.SetProperty(vtk.vtkVolumeProperty())
volume.GetProperty().SetColor(colorTransferFunction)
volume.GetProperty().SetScalarOpacity(opacityTransferFunction)

# add an outline to the volume rendered data using vtkOutlineFilter and add the resulting vtkActor object to the vtkRenderer object
outline = vtk.vtkOutlineFilter()
outline.SetInputData(imageData)
outlineMapper = vtk.vtkPolyDataMapper()
outlineMapper.SetInputConnection(outline.GetOutputPort())
outlineActor = vtk.vtkActor()
outlineActor.SetMapper(outlineMapper)

# set the ambient, diffuse, and specular parameters for Phong shading
ambient = 0.5
diffuse = 0.5
specular = 0.5

usePhongShading = input("Do you want to use phong shading (y/n)? ").lower() == "y"

if(usePhongShading):
    volume.GetProperty().ShadeOn()
    volume.GetProperty().SetAmbient(ambient)
    volume.GetProperty().SetDiffuse(diffuse)
    volume.GetProperty().SetSpecular(specular)

# create a vtkRenderer object
renderer = vtk.vtkRenderer()
renderer.SetBackground(0.9,0.9,0.9)
renderer.AddVolume(volume)
renderer.AddActor(outlineActor)

# create a vtkRenderWindow object with a size of 1000x1000
renderWindow = vtk.vtkRenderWindow()
renderWindow.SetSize(1000, 1000)

# create a vtkRenderWindowInteractor object and set its render window to the vtkRenderWindow object
renderWindowInteractor = vtk.vtkRenderWindowInteractor()
renderWindowInteractor.SetRenderWindow(renderWindow)

# add the vtkRenderer object to the vtkRenderWindow object
renderWindow.AddRenderer(renderer)

#Set some renderer view properties
renderer.ResetCamera()
renderer.GetActiveCamera().Azimuth(180)
renderer.GetActiveCamera().Elevation(-5)
renderer.ResetCameraClippingRange()

#Initialize renderer window
renderWindowInteractor.Initialize()
renderWindowInteractor.Start()

