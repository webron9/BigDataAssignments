**** Big Data Visual Analytics Assignment 2 ****

1] 2D Isocontour extraction

- Input data used here is "Isabel_2D.vti"
- Run the file "isocontour.py" for getting the extracted isocontour.
- You will need to provide the input parameter which will be the contour value at which you want to see the isocontour.
- Range of this input parameter is [-1434.86 to 630.569], as given in the Isabel_2D dataset.
- So, you won't get any contour if you give parameter out of this range or very close to the range.
- Output isocontour is returned to file "output.vtp".
- Assuming you run the "isocontour.py" file already, open the "output.vtp" file in ParaView software and press on "apply" button to see the output.
- If the output is not visible, please try to change the background color in the ParaView software.

2] VTK Volume Rendering and Transfer function

- Input data used here is "Isabel_3D.vti"
- Run the file "volume_renderer.py" for getting the rendered output.
- You will need to provide the input parameter which will be the choice that you want to use phong shading or not.
- Provide input "y" if you want to use the phong shading and "n" if you don't want to use the phong shading.
- A rendered window will be popped up after running the "volume_renderer.py" file. 
- Two different windows are possible depending on the input you provided.
