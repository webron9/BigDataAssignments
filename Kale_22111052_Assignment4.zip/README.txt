## Assignment 4 (22111052) ##

1) Install required libraries
- libraries used -> vtk,numpy,scipy

2) Run srs_volumeRecons.py file for getting sampled points(sampled_points_<input_percentage>.vtp) and volume reconstructed (recons_volume_{grid_method}.vtp) as output.

3) Enter sampling percentage as input in range 1 to 100. Enter gridding method ['nearest','linear'] as input. 

3) I included analysis_22111052.pdf file for comparing noise-to-signal (nsr) ratio and reconstruction time for [1,3,5]pct and gridding methods nearest and linear.