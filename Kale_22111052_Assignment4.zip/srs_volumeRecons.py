import vtk
import random
import numpy as np
from scipy.interpolate import griddata
from vtk.util.numpy_support import vtk_to_numpy,numpy_to_vtk
import time

def compute_SNR(arrgt, arr_recon):
    diff = arrgt - arr_recon
    sqd_max_diff = (np.max(arrgt) - np.min(arrgt))**2
    snr = 10 * np.log10(sqd_max_diff / np.mean(diff**2))
    return snr

def handle_nan(data):
    # Replace any NaN values in the data with nearest neighbor values
    x, y, z = np.indices(data.shape)
    nan_indices = np.isnan(data)
    data[nan_indices] = griddata((x[~nan_indices], y[~nan_indices], z[~nan_indices]), data[~nan_indices], (x[nan_indices], y[nan_indices], z[nan_indices]), method='nearest')
    return data

def SimpleRandomSampler(percentage):
    # Load .vti file
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName('Isabel_3D.vti')
    reader.Update()
    input_data = reader.GetOutput()

    # Get number of points in the dataset
    num_points = input_data.GetNumberOfPoints()

    # Calculate number of points to sample based on percentage
    num_points_to_sample = int(num_points * percentage / 100)

    # Perform random sampling
    sampled_indices = random.sample(range(num_points), num_points_to_sample)

    #identifying corner points for the sampled points array
    dims = input_data.GetDimensions() 
    corner_points = [(0,0,0), (dims[0]-1,0,0), (0,dims[1]-1,0), (0,0,dims[2]-1), 
                  (dims[0]-1,dims[1]-1,0), (dims[0]-1,0,dims[2]-1), (0,dims[1]-1,dims[2]-1), 
                  (dims[0]-1,dims[1]-1,dims[2]-1)]
    
    # Create a new point set to store the sampled points
    sampled_points = vtk.vtkPoints()
    #sampled_points.SetNumberOfPoints(num_points_to_sample + len(corner_points))
    
    # Create a list to store the values of all sampled points
    sampled_values = []
    
    nx, ny, nz = dims
    for idx in corner_points:
        i, j, k = idx
        linear_idx = k*nx*ny + j*nx + i
        point = input_data.GetPoint(linear_idx)
        data = input_data.GetScalarComponentAsDouble(i, j, k, 0)
        sampled_points.InsertNextPoint(point)
        sampled_values.append(data)

    # Loop through the sampled indices and retrieve the point coordinates and values
    for i, idx in enumerate(sampled_indices):
        point = input_data.GetPoint(idx)
        value = input_data.GetPointData().GetScalars().GetValue(idx)
        sampled_points.InsertNextPoint(point)
        sampled_values.append(value)

    # Create a new polydata to store the sampled points
    sampled_polydata = vtk.vtkPolyData()
    s = sampled_points.GetNumberOfPoints()
    sampled_polydata.SetPoints(sampled_points)

    scalars = vtk.vtkFloatArray()
    scalars.SetName("Pressure")
    for data in sampled_values:
        scalars.InsertNextValue(data)
    sampled_polydata.GetPointData().SetScalars(scalars)
    # Write the sampled points to a .vtp file
    writer = vtk.vtkXMLPolyDataWriter()
    writer.SetFileName("sampled_points_" + str(int(percentage)) + ".vtp")
    writer.SetInputData(sampled_polydata)
    writer.Write()
    pct = int(percentage)
    print(f'Saved {num_points_to_sample} sampled points to sampled_points_{pct}.vtp.')

    return sampled_polydata

def reconstruct_volume(sampled_polydata,method):
    reader = vtk.vtkXMLImageDataReader()
    reader.SetFileName('Isabel_3D.vti')
    reader.Update()
    input_data = reader.GetOutput()

    sampled_vtk_data = sampled_polydata.GetPointData().GetArray("Pressure")
    data = vtk_to_numpy(sampled_vtk_data)

    # Extract the point coordinates from the polydata
    sampled_vtk_points = sampled_polydata.GetPoints()
    sampled_points = vtk_to_numpy(sampled_vtk_points.GetData())

    dims = input_data.GetDimensions() 
    # Create the grid for reconstruction
    x = np.linspace(0, dims[0] - 1, dims[0])
    y = np.linspace(0, dims[1] - 1, dims[1])
    z = np.linspace(0, dims[2] - 1, dims[2])
    xx, yy, zz = np.meshgrid(z, y, x, indexing='ij')

    start_time = time.time()
    if(method == 'nearest'):
        recons_data = griddata(sampled_points, data,(zz, yy, xx), method='nearest')
    else:
        recons_data = griddata(sampled_points, data,(zz, yy, xx), method='linear', fill_value=np.nan)
        recons_data = handle_nan(recons_data)
    end_time = time.time()

    # Create a VTKImageData object to store the reconstructed recons_volume
    recons_volume = vtk.vtkImageData()
    recons_volume.SetDimensions(dims)
    recons_volume.SetSpacing(1, 1, 1)
    recons_volume.SetOrigin(0, 0, 0)

    # Assign the reconstructed data to the recons_volume
    recons_vtk_data = numpy_to_vtk(recons_data.flatten(), deep=True)
    recons_vtk_data.SetName('Pressure')
    recons_volume.GetPointData().SetScalars(recons_vtk_data)

    # Calculate the SNR between the original and reconstructed recons_volumes
    arrgt = vtk_to_numpy(input_data.GetPointData().GetScalars())
    arr_recon = vtk_to_numpy(recons_volume.GetPointData().GetScalars())

    # snr_nearest = computer_SNR(arrgt, arr_recon_nearest)
    snr = compute_SNR(arrgt, arr_recon)

    if method=='nearest':
        print("SNR for nearest interpolation:", snr)
    else:
        print("SNR for linear interpolation:", snr)
    print(f'Total reconstruction time is : {end_time-start_time}')
    # Write the reconstructed recons_volume to disk as a VTI file
    writer = vtk.vtkXMLImageDataWriter()
    writer.SetFileName(f'recons_volume_{method}.vti')
    writer.SetInputData(recons_volume)
    writer.Write()
    print(f'Volume Reconstruction is completed and saved in recons_volume_{method}.vti')

pct = float(input('Enter sampling percentage [1 to 100]: '))
method = input('Enter reconstruction method (nearest or linear): ')
sam_pdt = SimpleRandomSampler(pct)
reconstruct_volume(sam_pdt, method)